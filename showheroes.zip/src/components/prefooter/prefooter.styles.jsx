import styled from 'styled-components';

export const TextContainer = styled.div`
    padding: 10px 15px;
`;

export const Paragraph = styled.p`
    color: #5f5959;
`;
