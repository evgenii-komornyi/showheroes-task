import styled from 'styled-components';

export const VideoContainer = styled.video`
    width: 100%;
`;
