import React from 'react';

import { Tabs } from './tabs/tabs.component';
import { TabContent } from './tabs/tab-content.component';

export const CarsInfo = () => {
    return (
        <>
            <Tabs />
            <TabContent />
        </>
    );
};
