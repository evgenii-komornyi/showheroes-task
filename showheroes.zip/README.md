# ShowHeroes Task

To install this project: type in git bash:

npm install

or

yarn install
